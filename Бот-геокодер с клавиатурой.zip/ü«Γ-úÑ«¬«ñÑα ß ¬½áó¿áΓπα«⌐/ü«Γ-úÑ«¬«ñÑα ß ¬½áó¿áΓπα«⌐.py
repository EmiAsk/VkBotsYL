from vk_api import VkApi
from vk_api.utils import get_random_id
from vk_api.upload import VkUpload
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
from vk_api.longpoll import VkEventType, VkLongPoll

from maps_api import get_picture


TOKEN = 'a2d5ab8ff0620607f37970f89a3d6605e09c543da8a6cc48e223ac1126305654c6741f81aec1825807bce'
MAP_TYPES = {'схема': 'map', 'спутник': 'sat'}
# ссылка на группу-бота (писать ему в лс) - https://vk.com/club203903187


def send_message(user_id, text, kb=None, attach=None):
    vk.messages.send(user_id=user_id, message=text, random_id=get_random_id(), keyboard=kb,
                     attachment=attach)


vk_session = VkApi(token=TOKEN)
vk = vk_session.get_api()
upload = VkUpload(vk_session)
longpoll = VkLongPoll(vk_session)

keyboard = VkKeyboard(one_time=True)
keyboard.add_button('Схема', VkKeyboardColor.PRIMARY)
keyboard.add_button('Спутник', VkKeyboardColor.PRIMARY)

keyboard_shown, first_msg = False, True
address = None

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        if event.to_me and event.from_user:
            if first_msg:
                msg = 'Добрый день! Напишите какую местность вы хотите увидеть?'
                send_message(event.user_id, msg)
                first_msg = False
                continue
            elif not keyboard_shown:
                address = event.text
                msg = 'Выберите тип отображаемой карты'
                send_message(event.user_id, msg, kb=keyboard.get_keyboard())
                keyboard_shown = True

            elif keyboard_shown:
                map_type: str = MAP_TYPES.get(event.text.lower())

                if map_type is None:
                    msg = 'Неверный тип карты! Повторите ввод!'
                    send_message(event.user_id, msg, kb=keyboard.get_keyboard())
                    continue

                image = get_picture(address, map_type=map_type)

                if image is None:
                    msg = 'Не удалось найти адрес! Повторите ввод адреса!'
                    send_message(event.user_id, msg)
                    keyboard_shown = False
                else:
                    response = upload.photo_messages([image], peer_id=event.peer_id)[0]
                    photo_url = f'photo{response["owner_id"]}_{response["id"]}'
                    msg = f'Это {address}. Напишите, что ещё хотите увидеть?'
                    send_message(event.user_id, msg, attach=[photo_url])
                    keyboard_shown = False

