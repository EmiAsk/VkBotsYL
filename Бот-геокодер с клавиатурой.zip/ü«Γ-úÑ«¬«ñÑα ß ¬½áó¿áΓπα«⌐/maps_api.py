from requests import get
from io import BytesIO


API_GEOCODER = 'https://geocode-maps.yandex.ru/1.x/'
API_STATIC = 'https://static-maps.yandex.ru/1.x/'
API_KEY_GEOCODER = '40d1649f-0493-4b70-98ba-98533de7710b'


def get_coords_by_address(address: str):
    """Получение координат по адресу"""

    response = get(API_GEOCODER, params={'geocode': address,
                                         'apikey': API_KEY_GEOCODER, 'format': 'json'})

    if not response:
        print("Ошибка выполнения запроса:")
        print(response.url)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        return ''

    toponym = response.json()["response"]["GeoObjectCollection"]["featureMember"]
    if not toponym:
        return ''

    toponym = toponym[0]["GeoObject"]
    coodrinates: list = toponym["Point"]["pos"].split()

    return ','.join(coodrinates)


def get_picture(address: str, map_type):
    """Сохранение картинки"""

    coords = get_coords_by_address(address)
    if not coords:
        return

    response = get(API_STATIC, params={'l': map_type, 'll': coords, 'z': 16})

    if not response:
        print("Ошибка выполнения запроса:")
        print(response.url)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        return

    return BytesIO(response.content)


