import os
import vk_api


LOGIN, PASSWORD = '', ''
ALBUM_ID, GROUP_ID = '281562080', '204158023'
# Ссылка на группу для проверки - https://vk.com/club204158023


def main():
    vk_session = vk_api.VkApi(login=LOGIN, password=PASSWORD)

    try:
        vk_session.auth(token_only=True)
    except vk_api.AuthError as e:
        print(e)
        return

    upload = vk_api.VkUpload(vk_session)

    os.chdir('static/img')
    filenames = os.listdir()
    if filenames:
        upload.photo(filenames, album_id=ALBUM_ID, group_id=GROUP_ID)
    else:
        print('Фотографий нет!')


if __name__ == '__main__':
    main()

