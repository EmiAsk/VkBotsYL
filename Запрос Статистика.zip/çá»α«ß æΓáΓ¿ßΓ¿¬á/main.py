from flask import Flask, render_template
import vk_api

app = Flask(__name__)


@app.route('/vk_stat/<int:group_id>')
def statistic(group_id):
    likes, comments, subscribed, ages, cities = get_statistic(group_id)
    return render_template("index.html", likes=likes, comments=comments, subscribed=subscribed,
                           ages=ages, cities=cities)


def get_statistic(group_id):
    login, password = '', ''
    vk_session = vk_api.VkApi(login, password)
    try:
        vk_session.auth(token_only=True)
    except vk_api.AuthError as error_msg:
        print(error_msg)
        return

    vk = vk_session.get_api()
    likes = 0
    comments = 0
    subscribed = 0
    ages = []
    cities = []
    statistic = vk.stats.get(group_id=group_id, stats_groups="reach", intervals_count=10)
    for stat in statistic:
        if "activity" in stat:
            likes += stat["activity"].get("likes", 0)
            comments += stat["activity"].get("comments", 0)
            subscribed += stat["activity"].get("subscribed", 0)
            ages.append(stat["reach"].get("age", []))
            cities.append(stat["reach"].get("cities", []))

    all_ages = {
        "12-18": 0,
        "18-21": 0,
        "21-24": 0,
        "24-27": 0,
        "27-30": 0,
        "30-35": 0,
        "35-45": 0,
        "45-100": 0

    }

    all_cities = []

    for item in ages:
        for age in item:
            all_ages[age["value"]] += age["count"]

    for item in cities:
        for city in item:
            all_cities.append(city["name"])
    all_cities = set(all_cities)
    all_cities = list(all_cities)

    return likes, comments, subscribed, all_ages, all_cities


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
